<?php 
include("../config.php");

if ($_POST['page']):
$page = $_POST['page'];
$requestFor = $_POST['pageName'];

  class Coupon
{
	public $couponid;
	public $category;
	public $name;
        public $description;
        public $price;
        public $image;
}
//$page = 1;
$cur_page = $page;
$page -= 1;
$per_page = 6;
$start = $page * $per_page;
$x = '';
if( 0 == strcasecmp($requestFor,'allcoupons'))
{
$x = 'all a to z';
}
else if ( 0 == strcasecmp($requestFor,'dealday'))
{
$x = 'dealday';
} 
else if ( 0 == strcasecmp($requestFor,'favourite'))
{
$x = 'favourite';
}
else
{
$x = 'recommended';

}
$query2 = "SELECT * FROM `main_coupons` Where 1 LIMIT $start, $per_page";
$result_pag_data = mysql_query($query2)or die('MySql Error' . mysql_error()); 

$i = 0; 
$Coupons = array();
while ($row = mysql_fetch_array($result_pag_data))
{
 $Coupons[$i] = new Coupon;
$Coupons[$i]->couponid = $row['id'];
$Coupons[$i]->name = $row['name'].$x;

$sql="SELECT * FROM categories WHERE id='".$row['cat_id']."' ";
$res=mysql_query($sql);
$r=mysql_fetch_array($res);
$count=mysql_num_rows($res);
if($count==1)
    {   
        $categoryname=$r['name'];   
    }

$Coupons[$i]->category = $categoryname; 
$Coupons[$i]->description = $row['description'];
$Coupons[$i]->price = $row['price'];
$Coupons[$i]->image = "http://trumachealthcare.net/trinity/uploads/".$row['image'];

$i++;
}

echo json_encode($Coupons); 
 endif;
?>