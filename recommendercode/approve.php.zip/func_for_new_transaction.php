<?php
function func($last_transactions , $new_coupon , $coupon_id , $i , $min_constant )
{
    $bahar = 0;
    $min = $min_constant;
    $max = 0;
    $min_pos = -1;
    $j = 1;
    
    $valid_from = $last_transactions[$i]["valid_from"];
    for($j=1 ; $j<=15 && $last_transactions[$i]["sc".$j."_id"]!=NULL ; $j++)
    {
        if($last_transactions[$i]["sc".$j."_id"] == $coupon_id)
            $bahar = 1;
    }
    
    if($bahar == 1)
    return;
    
    for($j=1 ; $last_transactions[$i]["sc".$j."_id"]!=NULL ; $j++)
    {
        $c_old = $last_transactions[$i]["sc".$j."_c_value"];
        $sc_id = $last_transactions[$i]["sc".$j."_id"];
        $min_max_hf = hf($sc_id,$j,$valid_from,$d,$c_old,$coupon_id,$max,$min);
        $min=$min_max_hf["min"];
        $min_pos = $min_max_hf["min_pos"];
    }
    $min_max_hf = hf($coupon_id , 0 , $valid_from , $d , $new_coupon["c_value"] , $last_transactions[$i]["id"], $max , $min);
    $hf_new_transaction_coupon = $min_max_hf["max"];
    
    $id_approved = $new_coupon["id"];
    $c_value_approved = $new_coupon["c_value"];
    $cat_id_approved = $new_coupon["cat_id"];
    
    if($j==16)
    {
        echo "bhara hua<br>";
        for($j=1 ; $last_transactions[$i]["sc".$j."_id"]!=NULL ; $j++)
        {
            $c_old = $last_transactions[$i]["sc".$j."_c_value"];
            $sc_id = $last_transactions[$i]["sc".$j."_id"];
            $min_max_hf = hf($sc_id,$j,$valid_from,$d,$c_old,$coupon_id,$max,$min);
            $min=$min_max_hf["min"];
            $min_pos = $min_max_hf["min_pos"];
        }
        $min_max_hf = hf($coupon_id , 0 , $valid_from , $d , $new_coupon["c_value"] , $last_transactions[$i]["id"], $max , $min);
        $hf_new_transaction_coupon = $min_max_hf["max"];
        //all similar coupon entries filled
        //so we ll replace at min_id
        
        $coupon_id = $last_transactions[$i]["id"];
        $query="update main_coupons set sc".$min_pos."_id = '".$id_approved."' , sc".$min_pos."_c_value='".$c_value_approved."' , sc".$min_pos."_cat_id = '".$cat_id_approved."' where id = '".$coupon_id."'";
        $result11 = mysql_query($query) or die("query1 nai challi");
    }
    else
    {
        echo "khali hai<br>";
        echo $j."<br>";
        $coupon_id = $last_transactions[$i]["id"];
        $query="update main_coupons set sc".$j."_id = '".$id_approved."' , sc".$j."_c_value='".$c_value_approved."' , sc".$j."_cat_id = '".$cat_id_approved."' where id = '".$coupon_id."'";
        $result11 = mysql_query($query)or die("query2 nai challi");
    }
}                    
?>