<?php

include 'config.php';
include 'hf.php';
include 'func_for_new_transaction.php';

$coupon_id=4;
$user_id=1;

class new_transaction{
    
    var $coupon_id;
    var $user_id;
    var $table_name;
    var $last_transactions;
    var $new_coupon;
    
    function new_transaction($coupon_id , $user_id , $number_of_last_transactions, $min_constant , $d)
    {
        $this->set_values($coupon_id , $user_id);
        $this->table_name = $this->transaction_table_name();
        $this->get_last_transactions($number_of_last_transactions , $this->table_name , $user_id);
        $this->insert_new_transaction($coupon_id , $user_id);
        
        for($i = 0 ; $i < count($this->last_transactions) ; $i++)
        {
            //try to increment the count
            //if entry is present count will be incremented
            //else null will be the result.
            echo $this->last_transactions[$i]["id"]."<br>";
            $query = "update counts set count = count+1 where coupon1_id = ".$this->coupon_id." and coupon2_id=".$this->last_transactions[$i]["id"]." or coupon2_id=".$this->coupon_id." and coupon1_id=".$this->last_transactions[$i]["id"];
            $result = mysql_query($query) or die("update query nahi challi");
            if(mysql_affected_rows()==0)
            {
                if($this->last_transactions[$i]["id"]!=$this->coupon_id)
                {
                    $query="insert into counts values ('".$this->last_transactions[$i]["id"]."','".$this->coupon_id."','1')";
                    $result22 = mysql_query($query) or die("counts table not upodated");
                    
                    func($this->last_transactions , $this->new_coupon , $this->coupon_id , $i , $min_constant);
                }
            }
            else
            {
                func($this->last_transactions , $this->new_coupon , $this->coupon_id , $i , $min_constant);
            }
        }
    }
    
    function insert_new_transaction($coupon_id , $user_id)
    {
        $query = "insert into ".$this->table_name." (user_id , coupon_id , transaction_timestamp) values ( '".$user_id."','".$coupon_id."' , now())";
        $result = mysql_query($query) or die("insert");
    }
    
    function get_last_transactions($number_of_last_transactions , $table_name , $user_id)
    {
        $query = "select * from ".$table_name." where user_id=".$user_id." order by transaction_timestamp desc limit ".$number_of_last_transactions;
        $result = mysql_query($query) or die("last transactions");
        while( $last_transactions = mysql_fetch_array($result))
        {
            $coupon_id1 = $last_transactions["coupon_id"];
            $query = "select * from main_coupons where id=".$coupon_id1;
            $result2 = mysql_query($query) or die("main_coupons");
            $main_coupon_row = mysql_fetch_array($result2);
            $this->last_transactions[] = $main_coupon_row;
        }
        
    }
    
    function set_values($coupon_id , $user_id)
    {
        $this->coupon_id = $coupon_id;
        $this->user_id = $user_id;
        $query = "select * from main_coupons where id =".$coupon_id;
        $result = mysql_query($query) or die("coupon not found");
        $row = mysql_fetch_array($result);
        $this->new_coupon = $row;
    }

    function transaction_table_name(){
        $query = "select table_name from transaction_table_identifier where ".$this->user_id." between user_from and user_to";
        $result = mysql_query($query) or die("table_name");
        $transaction_table = mysql_fetch_array($result);
        return $transaction_table["table_name"];
        }
}

$nt = new new_transaction($coupon_id , $user_id , $number_of_last_transactions , $min_constant , $d);

?>