<?php
$key = 1;
$value = 10;
$mohit[$key]=$value;
echo $mohit[$key];

?>