<?php
$connection = mysql_connect("localhost","karanpreet","fbid1992") or die("nahi hoya!");
$db = mysql_select_db("recommender3") or die("database kehnda nahi");
$d=13;
$min_constant=100000;
$number_of_categories = 3; // used to find categories interest of users
?>