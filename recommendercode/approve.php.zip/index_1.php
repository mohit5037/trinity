<?php
include 'config.php';
include 'hf.php';

$user_id=1;

class user_info
{
    var $name;
    var $other_details;
    
    function user_info($user_id)
    {
        $query = "select name,other_details from users where user_id=".$user_id;
        $result = mysql_query($query) or die("user_info query failed");
        $row = mysql_fetch_array($result);
        $this->name = $row["name"];
        $this->other_details = $row["other_details"];
    }
}

class category_ranks
{
    var $cat_ranks;
    
    function category_ranks($user_id, $number_of_categories)
    {
        $query = "select * from users where user_id=".$user_id;
        $result = mysql_query($query) or die("chali ni");
        $row = mysql_fetch_array($result);
        for($i=1;$i<$number_of_categories;$i++)
        {
            $this->cat_ranks[strval($row['cat'.$i.'_id'])] = $row['cat'.$i.'_rank'];
        }
    }
}
class transaction_history
{
    public $transactions_coupon_id;
    
    function transaction_history($user_id)
    {
        $query = "select table_name from transaction_table_identifier where ".$user_id." between user_from and user_to";
        $result = mysql_query($query) or die("chali ni");
        $row = mysql_fetch_array($result);
        $query="select coupon_id from ".$row[0]." where user_id=".$user_id." limit 10";
        $result = mysql_query($query) or die("chali ni");
        $i=0;
        while($row = mysql_fetch_array($result))
        {
            $this->transactions_coupon_id[$i++]=$row[0];
        }
    }
}

class user_profile
{
    public $ui, $cr, $th;
    public $map=array();
    
    function user_profile($user_id,$number_of_categories)
    {
        $this->ui=new user_info($user_id);
        $this->cr=new category_ranks($user_id,$number_of_categories);
        $this->th=new transaction_history($user_id);
    }
    
    function generate($d,$min_constant)
    {
        
        foreach($this->th->transactions_coupon_id as $coupon_id)
        {
            $query="select * from main_coupons where id=".$coupon_id;
            $result = mysql_query($query) or die("chali ni");
            while($row = mysql_fetch_array($result))
            {
                $j=1;
                while($row['sc'.$j."_id"]!=NULL)
                { 
                    $max = 0;
                    $min = $min_constant;
                    
                    $category=$row['sc'.$j."_cat_id"];
                    $category_rank=$this->cr->cat_ranks[$category];
                    
                    
                    $sc_id = $row['sc'.$j."_id"];
                    $c_old = $row["sc".$j."_c_value"];
                    $coupon_id = $row["id"];
                    
                    $min_max_hf = hf($sc_id,$j,$row["valid_from"],$d,$c_old,$coupon_id,$max,$min);
                    $hf=$min_max_hf["max"];
                    
                    $item_score=$hf*$category_rank;
                    
                    if(array_key_exists($coupon_id,$this->map))
                    {
                        $this->map[$coupon_id]+=$item_score;
                    }
                    else
                    $this->map[$coupon_id]=$item_score;
                    
                    $j++;
                } 
            }
        }
        
        foreach($this->map as $id=>$is)
        {
            echo $id." ".$is."<br>";
        }
        
    }
}

$up= new user_profile($user_id,$number_of_categories);
$up->generate($d,$min_constant);
?>