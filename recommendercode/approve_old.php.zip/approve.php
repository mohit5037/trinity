<?php
include("../config.php");
$d=13;
$min_constant=100000;
include 'hf.php';
$query = "select * from categories";
$result = mysql_query($query);
$row = mysql_fetch_array($result);
//echo $row["name"];

// coupon_id supplied by front end when admin clicks on approve button
//$coupon_id=2;

// variable to decide the priority of new coupon again supplied by front end
//$insert_level = 3;


class get_info
{
	var $cat_id, $merchant_id;
	
	function get_info($coupon_id)
	{
		$query = "select cat_id, merchant_id from premature";
		$result = mysql_query($query);
		$row = mysql_fetch_array($result);
		
		$this->cat_id = $row["cat_id"];
		$this->merchant_id = $row["merchant_id"];	
	}
}

class c_values
{
	var $max=0,$min;
	
	function c_values($cat_id, $d, $min_constant)
	{
		$this->min=$min_constant;
		$query="select * from main_coupons where cat_id=".$cat_id;
		$result=mysql_query($query);
		while($row = mysql_fetch_array($result))
		{
			$coupon_id=$row["id"];
			$j=1;
			while($row['sc'.$j."_id"]!=NULL)
			{
			    $sc_id=$row['sc'.$j."_id"];
			    /*$query = "select count from counts where coupon1_id=".$coupon_id." and coupon2_id=".$sc_id." or coupon2_id=".$coupon_id." and coupon1_id=".$sc_id;
			    $result0 = mysql_query($query);
			    $count = mysql_fetch_array($result0);*/
			    $c_old = $row["sc".$j."_c_value"];
			    
			    echo $sc_id." ".$row["valid_from"]." ".$c_old." ";
			    $min_max_hf = hf($sc_id,$j,$row["valid_from"],$d,$c_old,$coupon_id,$this->max,$this->min);
			    //echo $c_old."<br>";
			    
			    /*//getting the date of similar coupon
			    $query = "select valid_from from main_coupons where id=".$sc_id;
			    $result1 = mysql_query($query) or die("error");
			    $sc_date = mysql_fetch_array($result1);
			    //echo $sc_date[0]."<br>";
			    
			    //getting current date
			    $query = "select curdate()";
			    $result2 = mysql_query($query) or die("error");
			    $current_date = mysql_fetch_array($result2);
			    //echo $current_date[0]."<br>";
			    
			    $coupon_date=$row["valid_from"];
			    //$query = "select min(select datediff('".$current_date[0]."',date('".$sc_date[0]."')),datediff('".$current_date[0]."',date('".$coupon_date."'))))";
			    $query = "select datediff('".$current_date[0]."',date('".$sc_date[0]."'))";
			    $result3 = mysql_query($query);
			    $days_sc = mysql_fetch_array($result3);
			    
			    $query = "select datediff('".$current_date[0]."','".$coupon_date."')";
			    $result4 = mysql_query($query);
			    $days_coupon = mysql_fetch_array($result4);
			    
			    $min_days=($days_sc[0]<$days_coupon[0]?$days_sc[0]:$days_coupon[0]);
			    $hf = ( $c_old + $count[0] ) / ( $d + $min_days);
			    if($hf>$this->max)
			    $this->max=$hf;
			    if($hf<$this->min)
			    $this->min=$hf;
			    //echo $this->max." ".$this->min."<br>";
			    */
			    $this->max=$min_max_hf["max"];
			    $this->min=$min_max_hf["min"];
			    echo $this->max." ".$this->min."<br>";
			    $j++;
			} 
		}
	}
}

class inserter
{
	var $cv,$gi,$step,$c_value;
	
	function inserter($coupon_id,$d,$insert_level,$min_constant)
	{
		$this->gi=new get_info($coupon_id);
		$this->cv=new c_values($this->gi->cat_id,$d, $min_constant);
		$this->step();
		$this->generate_c_value($d,$insert_level);
		$this->shifter($coupon_id);
	}
	
	function step()
	{
		$this->step = ($this->cv->max - $this->cv->min)/5;
	}
	function generate_c_value($d,$insert_level)
	{
		$hf = $this->cv->min + $insert_level * $this->step;
		$this->c_value = round($d * $hf);
		echo $this->c_value;
	}
	function shifter($coupon_id)
	{
		$query="select * from premature where id=".$coupon_id;
		$result8 = mysql_query($query);
		$row = mysql_fetch_array($result8);
		
 date_default_timezone_set("Asia/Calcutta");
 $todaydate = new DateTime();
 $currenttime = date_format($todaydate, 'H:i:s d:m:Y');
                
                
		//$query="insert into approved values('".$row[0]."','".$this->c_value."','".$row[1]."','".$row[2]."','".$row[3]."',
                    //'".$row[4]."','".$row[5]."','".$row[6]."','".$row[7]."','".$row[8]."','".$currenttime."','".$row[9]."','".$row[10]."')";
	
    $query =    "INSERT INTO `approved`
           (`id`,`c_value`,`cat_id`, `name`, `description`, `create_date`, 
           `valid_from`, `valid_to`,`merchant_id`,`approved_date`, `image`, `price`)
VALUES ('".$coupon_id."','".$this->c_value."','".$row['cat_id']."','".$row['name']."','".$row['description']."','".$row['create_date']."',
'".$row['valid_from']."','".$row['valid_to']."','".$row['merchant_id']."','".$currenttime."','".$row['image']."','".$row['price']."')";                      
 $result9 = mysql_query($query);
 
 
$query2 = "DELETE FROM `premature` WHERE  `id`='".$coupon_id."'";
 $deleteresult = mysql_query($query2);
                
	}
}


?>