<?php
$connection = mysql_connect("localhost","karanpreet","fbid1992") or die("nahi hoya!");
$db = mysql_select_db("recommender") or die("database kehnda nahi");
$query = "select * from categories";
$result = mysql_query($query);
$row = mysql_fetch_array($result);
echo $row["name"];
$user_id=1;
class user_info
{
    var $name;
    var $other_details;
    
    function user_info($user_id)
    {
        $query = "select name,other_details from users where user_id=".$user_id;
        $result = mysql_query($query);
        $row = mysql_fetch_array($result);
        $this->name = $row["name"];
        $this->other_details = $row["other_details"];
    }
}

class category_ranks
{
    var $cat_id;
    var $ranks;
    
    function category_ranks($user_id)
    {
        $query = "select * from users where user_id=".$user_id;
        $result = mysql_query($query) or die("chali ni");
        $row = mysql_fetch_array($result);
        for($i=1;$i<3;$i++)
        {
            $cat_id[$i-1] = $row['cat'.$i.'_id'];
            $ranks[$i-1] = $row['cat'.$i.'_rank'];
        }
    }
}
class transaction_history
{
    var $transactions_coupon_id;
    
    function transaction_history($user_id)
    {
        $query = "select table_name from transaction_table_identifier where ".$user_id." between user_from and user_to";
        $result = mysql_query($query) or die("chali ni");
        $row = mysql_fetch_array($result);
        $query="select coupon_id from ".$row[0]." where user_id=".$user_id." limit 10";
        $result = mysql_query($query) or die("chali ni");
        $i=0;
        while($row = mysql_fetch_array($result))
        {
            $transactions_coupon_id[$i++]=$row[0];
        }
    }
}

class user_profile
{
    var $ui, $cr, $th;
    
    function user_profile($user_id)
    {
        $ui=new user_info($user_id);
        $cr=new category_ranks($user_id);
        $th=new transaction_history($user_id);
    }
}

$up= new user_profile($user_id);
?>