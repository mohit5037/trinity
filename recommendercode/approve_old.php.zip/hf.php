<?php

function hf($sc_id,$j,$valid_from,$d,$c_old,$coupon_id,$max1,$min1)
{
    $min=$min1;
    $max=$max1;
    
    $query = "select count from counts where coupon1_id=".$coupon_id." and coupon2_id=".$sc_id." or coupon2_id=".$coupon_id." and coupon1_id=".$sc_id;
    $result0 = mysql_query($query);
    $count = mysql_fetch_array($result0);
    
    //getting the date of similar coupon
    $query = "select valid_from from main_coupons where id=".$sc_id;
    $result1 = mysql_query($query) or die("error");
    $sc_date = mysql_fetch_array($result1);
    //echo $sc_date[0]."<br>";
    
    //getting current date
    $query = "select curdate()";
    $result2 = mysql_query($query) or die("error");
    $current_date = mysql_fetch_array($result2);
    //echo $current_date[0]."<br>";
    
    $coupon_date=$valid_from;
    //$query = "select min(select datediff('".$current_date[0]."',date('".$sc_date[0]."')),datediff('".$current_date[0]."',date('".$coupon_date."'))))";
    $query = "select datediff('".$current_date[0]."',date('".$sc_date[0]."'))";
    $result3 = mysql_query($query);
    $days_sc = mysql_fetch_array($result3);
    
    $query = "select datediff('".$current_date[0]."','".$coupon_date."')";
    $result4 = mysql_query($query);
    $days_coupon = mysql_fetch_array($result4);
    
    $min_days=($days_sc[0]<$days_coupon[0]?$days_sc[0]:$days_coupon[0]);
    $hf = ( $c_old + $count[0] ) / ( $d + $min_days);
    if($hf>$max)
    $max=$hf;
    $min_pos=-1;
    if($hf<$min){
        $min_pos = $j;
        $min=$hf;
    }
    
    $min_max_hf["min"]=$min;
    $min_max_hf["max"]=$max;
    $min_max_hf["min_pos"]=$min_pos;
    return $min_max_hf;
}

?>